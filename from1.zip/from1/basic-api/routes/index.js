
const express = require('express');
const axios = require('axios');
const registry = require('./registry.json');

const router = express.Router();

router.all('/:API_HU/:path', async (req, res) => {
    const API = req.params.API_HU;

    try {
        if (API !== 'api_gtw') {
            return res.status(404).send('Gateway not found');
        }

        const service = req.params.path;
        const destination = registry[service];

        if (!destination) {
            return res.status(404).send('Service not found');
        }

        const response = await axios.get(
            `${destination.url}/${service}`
        );

        res.send(response.data);

    } catch (error) {
        console.log('Error:', error.message);
        res.status(500).send('Microservice error');
    }
});

module.exports = router;
